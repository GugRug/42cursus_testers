## Objetivo
O propósito desta pasta é registrar parte do aprendizado adquirido durante as
sessões do codinoite.